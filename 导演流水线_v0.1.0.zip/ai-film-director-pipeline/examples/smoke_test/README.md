# 最小冒烟测试

目的：一张图 + 一段 3 秒视频 + 一张卡，验证环境与四个脚本的基本链路是否正常。

## 前置
- Python 3.9+ 与 Pillow（`pip install -r requirements.txt`）
- ffmpeg / ffprobe 可执行（加入 PATH，或用环境变量 `FFMPEG` 指定可执行文件路径）

## 运行
```bash
python examples/smoke_test/smoke.py
```

它会：
1. 用 ffmpeg 生成两段 3 秒测试片段（一段彩色、一段纯色）
2. 调 `make_cards.py` 出卷目卡与引文卡
3. 调 `contact_sheet.py` 把 1920×1080 与 1080×1080 混排（验证不变形）
4. 调 `post_make.py` 拼接，并用 ffprobe 断言输出**只有 video 流**（无音轨）

通过标准：最后一行打印 `冒烟测试 通过 ✔`。

产物在 `examples/smoke_test/work/`，可随时删。
